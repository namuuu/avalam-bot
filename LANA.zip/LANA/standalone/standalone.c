#include <stdio.h>
#include <stdlib.h>
#include <avalam.h>
#include <topologie.h>
#include <string.h>

#ifdef __DEBUG__
	#define affpos afficherPosition(p)
	#define cheminjs puts(chemin)
#else
	#define affpos
	#define cheminjs
#endif

void writeJSON(T_Position p,  T_Score score, char *chemin);



int main(int argc, char * argv[]){

	
	//chois du chemin d'enregistrement
	char chemin[1000]="";
	if(argc>1){
		
		//if(argv[])
		int i;
		for(i=1; i<argc-1;i++){ strcat(chemin,argv[i]); strcat(chemin,"/"); }
		strcat(chemin,argv[i]);
	
	}
	else strcat(chemin, "../web/data/refresh-data.js");
	cheminjs;

	
	T_Position p;
	int ori,dest;
	
	
	p = getPositionInitiale();
	
	int selecteur;
	

	writeJSON(p, evaluerScore(p),chemin);
	
	
	//initialisation des bonus a zero
	p.evolution.bonusJ =-1;
	p.evolution.bonusR =-1;
	p.evolution.malusR =-1;
	p.evolution.malusJ =-1;

	affpos;
	
//	initialisation des bonus malus
	do{
		
	printf("\n bonus Jaune:");
	scanf("%d",&selecteur);
	p.evolution.bonusJ = selecteur;	

	}while(p.cols[selecteur].couleur != JAU);
	affpos;
	writeJSON(p, evaluerScore(p),chemin);//mettre a jour json du plateau
	

	do{
	printf("\n bonus Rouge:");
	scanf("%d",&selecteur);
	p.evolution.bonusR = selecteur;

	}while(p.cols[selecteur].couleur != ROU);
	affpos;
	writeJSON(p, evaluerScore(p),chemin);//mettre a jour json du plateau
	

	do{
	printf("\n malus Rouge:");
	scanf("%d",&selecteur);
	p.evolution.malusR = selecteur;
	}while((p.cols[selecteur].couleur != ROU) || (p.evolution.malusR == p.evolution.bonusR));
	affpos;
	writeJSON(p, evaluerScore(p),chemin);//mettre a jour json du plateau
	

	do{
	printf("\n malus Jaune:");
	scanf("%d",&selecteur);
	p.evolution.malusJ = selecteur;
	}while((p.cols[selecteur].couleur != JAU) || (p.evolution.bonusJ == p.evolution.malusJ));
	affpos;
	writeJSON(p, evaluerScore(p),chemin);//mettre a jour json du plateau
	
	
	
	


//	boucle de jeu
	while(getCoupsLegaux(p).nb!=0)
	{
		
		
		afficherScore(evaluerScore(p));
		
		//jouer un coups
		printf("qui joue: %s", COLNAME(p.trait));
		
		printf("\n origine:");
		scanf("%d",&ori);
		
		printf("\n destination:");
		scanf("%d",&dest);
		
		p = jouerCoup(p, ori, dest);
		
		
	
		affpos;
		writeJSON(p, evaluerScore(p),chemin);//mettre a jour json du plateau

		
	}

	//afficher qui  a gagner + les point
	if(evaluerScore(p).nbJ==evaluerScore(p).nbR)//si egalité
	{
		if(evaluerScore(p).nbJ5<evaluerScore(p).nbR5)printf("\nRouge gagnant\n"); else printf("\njaune gagnant\n"); return 0;
	}

	if(evaluerScore(p).nbJ<evaluerScore(p).nbR)printf("\nRouge gagnant\n"); else printf("\njaune gagnant\n"); return 0;

	
	
	return 0;
}


//	fonction de création de json
void writeJSON(T_Position p, T_Score score, char *chemin) {


	
	FILE * fp;
	
	fp = fopen(chemin, "w+");
	fputs("traiterJson({\n", fp);

	
	
	fputs(STR_TURN":", fp);
	fprintf(fp, "%d,\n", p.trait);
	
	fputs(STR_SCORE_J":", fp);
	fprintf(fp, "%d,\n", score.nbJ);
	
	fputs(STR_SCORE_J5":", fp);
	fprintf(fp, "%d,\n", score.nbJ5);
	
	fputs(STR_SCORE_R":", fp);
	fprintf(fp, "%d,\n", score.nbR);
	
	fputs(STR_SCORE_R5":", fp);
	fprintf(fp, "%d,\n", score.nbR5);
	
	fputs(STR_BONUS_J":", fp);
	fprintf(fp, "%d,\n", p.evolution.bonusJ);
	
	fputs(STR_MALUS_J":", fp);
	fprintf(fp, "%d,\n", p.evolution.malusJ);
	
	fputs(STR_BONUS_R":", fp);
	fprintf(fp, "%d,\n", p.evolution.bonusR);
	
	fputs(STR_MALUS_R":", fp);
	fprintf(fp, "%d,\n", p.evolution.malusR);
	
	fputs(STR_COLS":[\n", fp);

	
	for(int i = 0; i < NBCASES-1; i++)
	{
		fprintf(fp, "\t{"STR_NB":%d, "STR_COULEUR":%d},\n", p.cols[i].nb,p.cols[i].couleur);
	}
	fprintf(fp, "\t{"STR_NB":%d, "STR_COULEUR":%d}\n]\n});", p.cols[NBCASES-1].nb,p.cols[NBCASES-1].couleur);
	
	
	fclose(fp); 

}
